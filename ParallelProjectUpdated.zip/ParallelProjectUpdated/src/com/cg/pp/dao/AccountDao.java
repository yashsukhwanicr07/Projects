package com.cg.pp.dao;

import java.util.List;
import java.util.Map;
import com.cg.pp.bean.AccountHolder;
import com.cg.pp.bean.Transactions;
import com.cg.pp.bean.Wallet;
import com.cg.pp.exception.AccountNotExistException;
import com.cg.pp.exception.FieldCannotBeNullException;
import com.cg.pp.exception.MobileNumberAlreadyExistException;
import com.cg.pp.exception.NotEnoughBalanceException;
import com.cg.pp.util.CollectionUtil;

public class AccountDao implements IAccountDao{

	CollectionUtil collect=null;
	Map<String,AccountHolder> accountMap=null;
	AccountHolder account=null;
	Wallet wallet=null;
	double balance=0.0;
	int transactionID=1;
	
	public AccountDao() {
		// TODO Auto-generated constructor stub
		collect=new CollectionUtil();
		accountMap=collect.getAccountDetails();
	}

	@Override
	public AccountHolder createAccount(String firstName, String lastName, String mobileNo, String gender, int age,
			double amount) throws FieldCannotBeNullException, MobileNumberAlreadyExistException{
		// TODO Auto-generated method stub 
		if(firstName==null || lastName==null || mobileNo==null || gender==null)
		{
			throw new FieldCannotBeNullException("Field can not be empty");
		}
		else if(accountMap.containsKey(mobileNo))
		{
			throw new MobileNumberAlreadyExistException("Mobile Number Already Exist");
		}
		else
		{
			 accountMap.put(mobileNo, new AccountHolder(firstName,lastName,gender,age,amount));
		}
		 return accountMap.get(mobileNo);
	}

	@Override
	public AccountHolder withdrawAmount(String mobileNo, double amount) throws NotEnoughBalanceException, AccountNotExistException 
	{
		// TODO Auto-generated method stub
		
		account=accountMap.get(mobileNo);
		if(account==null)
		{
			throw new AccountNotExistException("Account does not exist");
		}
		else
		{
			if(account.getWallet().getBalance()<amount)
			{
				throw new NotEnoughBalanceException("Insufficient Balance");
			}
			else
			{
				account.getWallet().setBalance(account.getWallet().getBalance()-amount);
				//Update transaction
				Transactions trans=account.getWallet().getTransaction();
				trans.setTransactionType("Withdraw");
				trans.setAmount(amount);
				trans.setTransactionId(transactionID++);
				trans.getListTransaction().add(trans);
				return account;
			}
		}
	}	
		

	@Override
	public AccountHolder depositAmount(String mobileNo, double amount) throws AccountNotExistException {
		// TODO Auto-generated method stub
		
		account=accountMap.get(mobileNo);
		if(account==null)
		{
			throw new AccountNotExistException("Account does not exist");
		}
		else
		{
		account.getWallet().setBalance(account.getWallet().getBalance()+amount);
		
		//Update transaction
		Transactions trans= new Transactions();
		trans.setAmount(amount);
		trans.setTransactionId(transactionID++);
		trans.setTransactionType("Deposit");
		account.getWallet().getTransaction().getListTransaction().add(trans);
		return account;
		}
	}

	@Override
	public double showBalance(String mobileNo) throws AccountNotExistException {
		if(account!=null)
		{
		account=accountMap.get(mobileNo);
		return account.getWallet().getBalance();
		}
		else
			throw new AccountNotExistException("Account does not exist");
	}

	@Override
	public String fundTransfer(String senderMobileNo,String receiverMobileNo, double amount) throws AccountNotExistException, NotEnoughBalanceException {
		AccountHolder senderAccount=null;
		AccountHolder receiverAccount=null;
		senderAccount=accountMap.get(senderMobileNo);
		receiverAccount=accountMap.get(receiverMobileNo);
		if(senderAccount==null)
		{
			throw new AccountNotExistException("Sender Account does not exist");
		}
		else if(receiverAccount==null)
		{
			throw new AccountNotExistException("Receiver Account does not exist");
		}
		try {
			if(senderAccount.getWallet().getBalance()<amount)
			{
				throw new NotEnoughBalanceException("Insufficient Balance in Sender's Account");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		senderAccount.getWallet().setBalance(senderAccount.getWallet().getBalance()-amount);
		receiverAccount.getWallet().setBalance(receiverAccount.getWallet().getBalance()+amount);
		
		//Update transaction
		//Sender's account
		senderAccount.getWallet().getTransaction().setAmount(amount);
		senderAccount.getWallet().getTransaction().setTransactionType("Debited");
		senderAccount.getWallet().getTransaction().setTransactionId(transactionID++);
		Transactions senderTrans=senderAccount.getWallet().getTransaction();
		senderAccount.getWallet().getTransaction().getListTransaction().add(senderTrans);
				
		//Reciever's account
		receiverAccount.getWallet().getTransaction().setAmount(amount);
		
		receiverAccount.getWallet().getTransaction().setTransactionId(transactionID++);
		receiverAccount.getWallet().getTransaction().setTransactionType("Credited");
		Transactions rectrans=receiverAccount.getWallet().getTransaction();
		receiverAccount.getWallet().getTransaction().getListTransaction().add(rectrans);
				
		return "Fund successfully transferred";
	}

	@Override
	public List<Transactions> printTtansaction(String mobileNo) 
	{
		List<Transactions> list=null;
		AccountHolder accountholder=accountMap.get(mobileNo);
		if(accountholder!=null)
		{
		list=accountholder.getWallet().getTransaction().getListTransaction();	
		}
		else
		{
			try {
				throw new AccountNotExistException("Receiver Account does not exist");
			} catch (AccountNotExistException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return list;
	}
}
