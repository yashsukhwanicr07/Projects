package com.cg.pp.bean;

import java.util.ArrayList;
import java.util.List;

public class Transactions {
	
	private int transactionId;
	private String transactionType;
	private double amount;
	private List<Transactions> listTransaction=null;
	
	public Transactions() {
		super();
		listTransaction=new ArrayList<Transactions>();
	}
	
	public int getTransactionId() {
		return transactionId;
	}
	
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public String getTransactionType() {
		return transactionType;
	}
	
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	
	public double getAmount() {
		return amount;
	}
	
	public void setAmount(double amount) {
		this.amount = amount;
	}
	
	
	public List<Transactions> getListTransaction() {
		return listTransaction;
	}

	public void setListTransaction(List<Transactions> listTransaction) {
		this.listTransaction = listTransaction;
	}

	@Override
	public String toString() 
	{
		System.out.println("-----------------------------------------------------------------------");
		return "transactionId=" + transactionId + ", transactionType="+ transactionType + ", amount=" + amount +"\n";
	}

}
