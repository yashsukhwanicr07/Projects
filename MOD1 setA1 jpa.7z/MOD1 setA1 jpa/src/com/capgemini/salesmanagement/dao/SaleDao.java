package com.capgemini.salesmanagement.dao;

import java.util.HashMap;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.util.SaleUtil;

public class SaleDao implements ISaleDAO 
{
	EntityManager em=null;
	EntityTransaction entitytran=null;
	public SaleDao()
	{
		em=SaleUtil.getEntityManager();
		entitytran=em.getTransaction();
	}
	@Override
	public boolean insertSalesDetails(Sale sale)
	{
		//System.out.println(sale);
		entitytran.begin();
		//em.persist(sale);
		//return true;
		String search="UPDATE Sale a set a.prodName='Barbee Doll' where a.saleId=31";
//		TypedQuery<Sale> query=em.createQuery(search, Sale.class);
//		List<Sale> list=query.getResultList();
//		for(Sale i:list)
//		{
//			System.out.println(i);
//		}
		Query query1=em.createQuery(search);
		int c=query1.executeUpdate();
		System.out.println(c);
		entitytran.commit();
//		for(Sale i:list1)
//		{
//			System.out.println(i);
//		}
		return true;
	}
}
