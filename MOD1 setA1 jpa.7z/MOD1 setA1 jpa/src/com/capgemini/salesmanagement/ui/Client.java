package com.capgemini.salesmanagement.ui;

import java.util.*;
import java.util.Scanner;

import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.service.SaleService;

public class Client {

	public static void main(String[] args) 
	{
		Scanner scanner=new Scanner(System.in);
		SaleService saleser=new SaleService();
		Sale sale=new Sale();
		while(true)		{
		try {
//		System.out.println("Enter product Code");
//		int prodCode=scanner.nextInt();
//		if(saleser.ValidateProdCode(prodCode))
//		{
//			sale.setProdCode(prodCode);
//		}
//		System.out.println("Enter the Quantity");
//		int qty=scanner.nextInt();
//		if(saleser.validateQuantity(qty))
//		{
//			sale.setQuantity(qty);
//		}
//		System.out.println("Enter Product Category");
//		String prodCat=scanner.next();
//		if(saleser.validateProdCat(prodCat))
//		{
//			sale.setCategory(prodCat);
//		}
//		System.out.println("Enter product name");
//		scanner.nextLine();
//		String prodName=scanner.nextLine();
//		if(saleser.validateName(prodName))
//		{
//			sale.setProdName(prodName);
//		}
//	System.out.println("Enter Product Price");
//	float price=scanner.nextFloat();
//	if(saleser.validateProdPrice(price))
//	{
//		sale.setTotal(price*qty);
//	}
//		Date date=new Date(2018,11,17);
//		sale.setDate(date);
		if(saleser.insertSalesDetails(sale));
		{
			System.out.println("Details persisted");
			break;
		}
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
      
	}
}
}
