package com.capgemini.salesmanagement.bean;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
@Table(name="Sale" )


public class Sale 
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int saleId;
	@Column(name="prodCode",length=20)
	private int prodCode;
	@Column(name="prodname",length=20)
	private String prodName;
	@Column(name="category",length=20)
	private String category;
	@Column(name="saledate")
	@Temporal(TemporalType.DATE)
	private java.util.Date saleDate;
	@Column(name="quantity",length=20)
	private int quantity;
	@Column(name="total",length=20)
	private float total;
	
	public Sale() {
		super();
		
	}
	public void setTotal(float total) {
		this.total = total;
	}
	public int getSaleId() {
		return saleId;
	}
	public float getTotal() {
		return total;
	}
	public int getProdCode() {
		return prodCode;
	}
	public void setProdCode(int prodCode) {
		this.prodCode = prodCode;
	}
	public String getProdName() {
		return prodName;
	}
	public void setProdName(String prodName) {
		this.prodName = prodName;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public java.util.Date getSaleDate() {
		return saleDate;
	}
	public void setDate(java.util.Date saleDate) {
		this.saleDate = saleDate;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	@Override
	public String toString() {
		return "Sale [saleId=" + saleId + ", prodCode=" + prodCode + ", prodName=" + prodName + ", category=" + category
				+ ", saleDate=" + saleDate + ", quantity=" + quantity + ", total=" + total + "]";
	}
	

}
