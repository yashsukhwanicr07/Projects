package com.cg.mr.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.mr.bean.Customer;
import com.cg.mr.dao.IEmployeeDAO;
@Transactional
@Service
public class EmployeeService implements IEmployeeService 
{
	@Autowired
	IEmployeeDAO servdao;
	@Override
	public String createCustomer(Customer customer) 
	{
		return servdao.createCustomer(customer);
	}

	@Override
	public String Recharge(String mobileno, double amount) {
		return servdao.Recharge(mobileno, amount);
	}

	@Override
	public Customer showCustomer(String mobileno) {
		return servdao.showCustomer(mobileno);
	}

}
