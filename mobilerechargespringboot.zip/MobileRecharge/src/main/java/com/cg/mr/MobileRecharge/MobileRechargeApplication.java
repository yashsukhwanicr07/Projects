package com.cg.mr.MobileRecharge;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.cg")
@EntityScan("com.cg")
public class MobileRechargeApplication {

	public static void main(String[] args) {
		SpringApplication.run(MobileRechargeApplication.class, args);
	}

}
