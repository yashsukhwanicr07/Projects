package com.cg.mr.frontcontroller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.mr.bean.Customer;
import com.cg.mr.service.IEmployeeService;

@RestController
public class FrontController 
{
	@Autowired
	IEmployeeService empserv;
	@RequestMapping(value="/createCustomer", method=RequestMethod.POST, consumes="application/json")
	public String createCustomer( @RequestBody Customer customer)
	{
		 return empserv.createCustomer(customer);
	}
	@RequestMapping(value="/rechargeAccount", method=RequestMethod.POST)
	public String rechargeAccount(@RequestParam("mobileno") String mobileNo,@RequestParam (name="amount") double amount)
	{
		return empserv.Recharge(mobileNo, amount);
	}
	@RequestMapping(value="/showCustomer/{mobileNo}", method=RequestMethod.GET, produces="application/json")
	public Customer showCustomer(@PathVariable String mobileNo)
	{
		return empserv.showCustomer(mobileNo);
	}

}
