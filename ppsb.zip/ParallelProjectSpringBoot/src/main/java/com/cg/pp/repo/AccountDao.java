package com.cg.pp.repo;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.springframework.stereotype.Repository;
import com.cg.pp.bean.AccountHolder;
import com.cg.pp.bean.Transactions;

@Repository("repo")
public class AccountDao implements IAccountDao{

	@PersistenceContext
	EntityManager entityManager;

	
	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	public AccountHolder createAccount(AccountHolder account) {
		 System.out.println(account);
		 entityManager.persist(account);
		 entityManager.flush();
		 return account;
	}

	@Override
	public AccountHolder withdrawAmount(String mobileNo, double amount)
	{
		
		AccountHolder account=entityManager.find(AccountHolder.class, mobileNo);
		account.getWallet().setBalance(account.getWallet().getBalance()-amount);
		account.getWallet().getListTransaction().add(new Transactions("Withdraw",amount));
		entityManager.merge(account);
	
		return account;
	}	
		

	@Override
	public AccountHolder depositAmount(String mobileNo, double amount)  {
		
		
		AccountHolder account=entityManager.find(AccountHolder.class, mobileNo);
		account.getWallet().setBalance(account.getWallet().getBalance()+amount);
		account.getWallet().getListTransaction().add(new Transactions("Deposit",amount));
		entityManager.merge(account);
		
		return account;
		
	}

	@Override
	public double showBalance(String mobileNo) {
		AccountHolder account=entityManager.find(AccountHolder.class, mobileNo);
		return account.getWallet().getBalance();
	}

	@Override
	public String fundTransfer(String senderMobileNo,String receiverMobileNo, double amount) {
		AccountHolder senderAccount=null;
		AccountHolder receiverAccount=null;
		senderAccount=entityManager.find(AccountHolder.class, senderMobileNo);
		receiverAccount=entityManager.find(AccountHolder.class, receiverMobileNo);
	
		senderAccount.getWallet().setBalance(senderAccount.getWallet().getBalance()-amount);
		receiverAccount.getWallet().setBalance(receiverAccount.getWallet().getBalance()+amount);
		senderAccount.getWallet().getListTransaction().add(new Transactions("Debited",amount));
		receiverAccount.getWallet().getListTransaction().add(new Transactions("Credited",amount));
		entityManager.merge(senderAccount);
		entityManager.merge(receiverAccount);
		
		return "Fund successfully transferred";
	}

	@Override
	public void printTransaction(String mobileNo) 
	{
		AccountHolder account=entityManager.find(AccountHolder.class, mobileNo);
		System.out.println(account.getWallet().getListTransaction());
	}
}

