package com.cg.pp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.cg.pp.bean.AccountHolder;
import com.cg.pp.service.IAccountService;

@RestController
public class AccountHolderController {

	@Autowired(required=true)
	IAccountService service;

	public IAccountService getService() {
		return service;
	}

	public void setService(IAccountService service) {
		this.service = service;
	}

	@RequestMapping(value="/createAccount",consumes="application/json",produces="application/json",method=RequestMethod.POST)
	public AccountHolder createAccount(@RequestBody AccountHolder account) {
		account=service.createAccount(account);
		return account;
	}
	
	/*@RequestMapping(value="/withdrawAmount",produces="application/json",method=RequestMethod.POST)
	public AccountHolder withdrawAmount(@RequestParam("mobno")String mobno,@RequestParam("amount")double amount) {
		
		account=service.withdrawAmount(mobno, amount);
		return account;
	}
	
	@RequestMapping(value="/depositAmount",produces="application/json",method=RequestMethod.POST)
	public AccountHolder depositAmount(@RequestParam("mobno")String mobno,@RequestParam("amount")double amount) {
		
		account=service.depositAmount(mobno, amount);
		return account;
	}*/
	
	@RequestMapping(value="/showBalance",method=RequestMethod.POST)
	public double showBalance(@RequestParam("mobno")String mobno) {
		double amount=service.showBalance(mobno);
		return amount;
	}
	
	@RequestMapping(value="/fundTransfer",method=RequestMethod.POST)
	public String fundTransfer(@RequestParam("senmobno")String senmobno,@RequestParam("recmobno")String recmobno,
			@RequestParam("amount")double amount) {
		String result=service.fundTransfer(senmobno, recmobno, amount);
		return result;
	}
	
	@RequestMapping(value="/printTransaction",method=RequestMethod.POST)
	public void printTransaction(@RequestParam("mobno")String mobno) {
		service.printTransaction(mobno);

	}
	
}
