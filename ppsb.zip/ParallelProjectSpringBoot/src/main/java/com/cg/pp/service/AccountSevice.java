package com.cg.pp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.cg.pp.bean.AccountHolder;
import com.cg.pp.repo.AccountDao;
import com.cg.pp.repo.IAccountDao;


@Transactional
@Service("service")
public class AccountSevice implements IAccountService{

	@Autowired
	IAccountDao repo;
	public AccountSevice() {
	
	}
	@Override
	public AccountHolder createAccount(AccountHolder account) {
		// TODO Auto-generated method stub
		return repo.createAccount(account);
	}
	@Override
	public AccountHolder withdrawAmount(String mobileNo, double amount) {
		// TODO Auto-generated method stub
		return repo.withdrawAmount(mobileNo, amount);
	}
	@Override
	public AccountHolder depositAmount(String mobileNo, double amount) {
		// TODO Auto-generated method stub
		return repo.depositAmount(mobileNo, amount);
	}
	@Override
	public double showBalance(String mobileNo) {
		// TODO Auto-generated method stub
		return repo.showBalance(mobileNo);
	}
	@Override
	public void printTransaction(String mobileNo) {
		// TODO Auto-generated method stub
		repo.printTransaction(mobileNo);
	}
	@Override
	public String fundTransfer(String senderMobileNo, String receiverMobileNo, double amount) {
		// TODO Auto-generated method stub
		return repo.fundTransfer(senderMobileNo, receiverMobileNo, amount);
	}
	
	
}
