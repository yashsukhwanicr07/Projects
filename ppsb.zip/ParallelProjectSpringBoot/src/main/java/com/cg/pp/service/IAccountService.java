package com.cg.pp.service;

import com.cg.pp.bean.AccountHolder;
import com.cg.pp.exception.AccountNotExistException;
import com.cg.pp.exception.NotEnoughBalanceException;

public interface IAccountService {

	public AccountHolder createAccount(AccountHolder account);
	public AccountHolder withdrawAmount(String mobileNo,double amount);
	public AccountHolder depositAmount(String mobileNo,double amount);
	public double showBalance(String mobileNo);
	public void printTransaction(String mobileNo);
	public String fundTransfer(String senderMobileNo,String receiverMobileNo,double amount);
	
}
