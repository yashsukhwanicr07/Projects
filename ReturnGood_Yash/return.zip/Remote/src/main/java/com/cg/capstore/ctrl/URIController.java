package com.cg.capstore.ctrl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.capstore.service.ICapstoreService;
import com.cg.capstore.bean.Product;
import com.cg.capstore.service.CapstoreServiceImpl;



@Controller
public class URIController 
{
	@Autowired
	ICapstoreService serviceref;
	
	public ICapstoreService getServiceref() {
		return serviceref;
	}
	public void setServiceref(ICapstoreService serviceref) {
		this.serviceref = serviceref;
	}
	@RequestMapping(value="/")
	public String myOrders(Model model)
	{
		List<Product> products=serviceref.findAllProducts();
		model.addAttribute("prod", products);
		return "index";
	}
	@RequestMapping(value="/return")
	public String returnpage(@RequestParam ("id") String productid,Model model)
	{
		serviceref.returnGood(productid);
		model.addAttribute("prodid", productid);
		return "returnPage";
	}
		
		
	}
	
