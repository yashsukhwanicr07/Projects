package com.cg.capstore.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.capstore.bean.Product;
import com.cg.capstore.repository.ICapstoreRepo;
@Service
@Transactional
public class CapstoreServiceImpl implements ICapstoreService 
{
	@Autowired
	ICapstoreRepo repositoryref;

	public ICapstoreRepo getRepositoryref() {
		return repositoryref;
	}

	public void setRepositoryref(ICapstoreRepo repositoryref) {
		this.repositoryref = repositoryref;
	}

	@Override
	public void returnGood(String productId) 
	{
		
		repositoryref.returnGood(productId);
	}

	@Override
	public List<Product> findAllProducts() 
	{
		return repositoryref.findAllProducts();
	}

}
