package com.cg.capstore.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.cg.capstore.bean.Product;

public interface ICapstoreService 
{
	public void returnGood(String productId);
	public List<Product> findAllProducts();

}
