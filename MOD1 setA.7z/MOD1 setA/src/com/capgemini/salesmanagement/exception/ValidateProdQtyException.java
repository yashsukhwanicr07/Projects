package com.capgemini.salesmanagement.exception;

public class ValidateProdQtyException extends Exception
{
	public ValidateProdQtyException(String str)
	{
		super(str);
	}

}
