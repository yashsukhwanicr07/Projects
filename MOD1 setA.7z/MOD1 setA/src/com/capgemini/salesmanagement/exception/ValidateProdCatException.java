package com.capgemini.salesmanagement.exception;

public class ValidateProdCatException extends Exception{
public ValidateProdCatException(String str)
{
	super(str);
}
}
